﻿namespace WindowsFormsFajlkezeles
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbSzoveg = new System.Windows.Forms.TextBox();
            this.listBoxTartalom = new System.Windows.Forms.ListBox();
            this.btnHozzad = new System.Windows.Forms.Button();
            this.btnMegnyit = new System.Windows.Forms.Button();
            this.btnMent = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // tbSzoveg
            // 
            this.tbSzoveg.Location = new System.Drawing.Point(181, 12);
            this.tbSzoveg.Name = "tbSzoveg";
            this.tbSzoveg.Size = new System.Drawing.Size(193, 26);
            this.tbSzoveg.TabIndex = 0;
            this.tbSzoveg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSzoveg_KeyDown);
            // 
            // listBoxTartalom
            // 
            this.listBoxTartalom.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBoxTartalom.FormattingEnabled = true;
            this.listBoxTartalom.ItemHeight = 20;
            this.listBoxTartalom.Location = new System.Drawing.Point(0, 0);
            this.listBoxTartalom.Name = "listBoxTartalom";
            this.listBoxTartalom.Size = new System.Drawing.Size(175, 450);
            this.listBoxTartalom.TabIndex = 0;
            this.listBoxTartalom.TabStop = false;
            // 
            // btnHozzad
            // 
            this.btnHozzad.Location = new System.Drawing.Point(181, 44);
            this.btnHozzad.Name = "btnHozzad";
            this.btnHozzad.Size = new System.Drawing.Size(193, 31);
            this.btnHozzad.TabIndex = 1;
            this.btnHozzad.Text = "Hozzáad";
            this.btnHozzad.UseVisualStyleBackColor = true;
            this.btnHozzad.Click += new System.EventHandler(this.btnHozzad_Click);
            // 
            // btnMegnyit
            // 
            this.btnMegnyit.Location = new System.Drawing.Point(182, 138);
            this.btnMegnyit.Name = "btnMegnyit";
            this.btnMegnyit.Size = new System.Drawing.Size(192, 30);
            this.btnMegnyit.TabIndex = 2;
            this.btnMegnyit.Text = "Megnyit";
            this.btnMegnyit.UseVisualStyleBackColor = true;
            this.btnMegnyit.Click += new System.EventHandler(this.btnMegnyit_Click);
            // 
            // btnMent
            // 
            this.btnMent.Location = new System.Drawing.Point(182, 174);
            this.btnMent.Name = "btnMent";
            this.btnMent.Size = new System.Drawing.Size(192, 30);
            this.btnMent.TabIndex = 3;
            this.btnMent.Text = "Ment";
            this.btnMent.UseVisualStyleBackColor = true;
            this.btnMent.Click += new System.EventHandler(this.btnMent_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Szöveges fájlok (*.txt)|*.txt|CSV fájlok (*.csv)|*.csv|Minden fájl (*.*)|*.*";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "txt";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 450);
            this.Controls.Add(this.btnMent);
            this.Controls.Add(this.btnMegnyit);
            this.Controls.Add(this.btnHozzad);
            this.Controls.Add(this.listBoxTartalom);
            this.Controls.Add(this.tbSzoveg);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbSzoveg;
        private System.Windows.Forms.ListBox listBoxTartalom;
        private System.Windows.Forms.Button btnHozzad;
        private System.Windows.Forms.Button btnMegnyit;
        private System.Windows.Forms.Button btnMent;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

