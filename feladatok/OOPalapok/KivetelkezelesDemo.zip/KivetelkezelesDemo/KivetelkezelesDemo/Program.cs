﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KivetelkezelesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //try
            //{
            //    new Harcos("asd", 4);
            //}
            //catch (ArgumentException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            List<string> content = new List<string>();
            Console.WriteLine("Kérem adja meg a megnyitni kívánt fájlt");
            string fajlNev = Console.ReadLine();
            try
            {
                using (var sr = new StreamReader(fajlNev))
                {
                    while (!sr.EndOfStream)
                    {
                        content.Add(sr.ReadLine());
                    }
                }
                var harcosok = File.ReadAllLines("haracosok.csv").ToList();
                foreach (var sor in harcosok)
                {
                    string[] sorSplit = sor.Split(';');
                    string nev = sorSplit[0];
                    int statuszSablon = int.Parse(sorSplit[1]);

                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Hiba történt a fájl nem található");
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            foreach (var item in content)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\nAdjon hozzá valamit a listához");

            content.Add(Console.ReadLine());

            try
            {
                using (var sw = new StreamWriter(fajlNev))
                {
                    foreach (var item in content)
                    {
                        sw.WriteLine(item);
                    }
                }
                //File.WriteAllLines(fajlNev, content);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }



            Console.ReadLine();
        }
    }
}
