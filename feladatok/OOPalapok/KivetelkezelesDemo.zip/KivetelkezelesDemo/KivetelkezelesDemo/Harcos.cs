﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KivetelkezelesDemo
{
    class Harcos
    {
        string nev;

        public Harcos(string nev, int statusSablon)
        {
            if (String.IsNullOrEmpty(nev.Trim()))
            {
                throw new ArgumentException("Hiba: A név nem lehet üres", "nev");
            }
            if (statusSablon < 1 || statusSablon > 3)
            {
                throw new ArgumentException("Hiba: A státusz sablon csak 1 és 3 közötti egész érték lehet", "statuszSablon");
                
            }
            this.nev = nev;
        }
    }
}
