﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsFajlkezeles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHozzad_Click(object sender, EventArgs e)
        {
            string szoveg = tbSzoveg.Text;
            if (String.IsNullOrWhiteSpace(szoveg))
            {
                MessageBox.Show("Üres a beviteli mező.");
                return;
            }
            if (listBoxTartalom.Items.Contains(szoveg))
            {
                MessageBox.Show("Ez már szerepel");
                return;
            }
            listBoxTartalom.Items.Add(szoveg);
            tbSzoveg.Text = "";
            tbSzoveg.Focus();
        }

        private void tbSzoveg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnHozzad.PerformClick();
            }
        }

        private void btnMent_Click(object sender, EventArgs e)
        {
            var result = saveFileDialog1.ShowDialog();
            if (result != DialogResult.OK)
            {
                return;
            }

            string fileName = saveFileDialog1.FileName;

            try
            {
                using (var sw = new StreamWriter(fileName))
                {
                    foreach (var item in listBoxTartalom.Items)
                    {
                        sw.WriteLine(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hiba a mentés során");
            }
        }

        private void btnMegnyit_Click(object sender, EventArgs e)
        {
            var result = openFileDialog1.ShowDialog();
            if (result != DialogResult.OK)
            {
                return;
            }

            string fileName = openFileDialog1.FileName;
            try
            {
                using (var sr = new StreamReader(fileName))
                {
                    listBoxTartalom.Items.Clear();
                    while (!sr.EndOfStream)
                    {
                        listBoxTartalom.Items.Add(sr.ReadLine());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hiba a megnyitás során");
            }
        }

    }
}
